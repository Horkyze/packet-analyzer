#!/bin/bash

clang -lpcap -g ../main.c -o ../bin/analyzer 

