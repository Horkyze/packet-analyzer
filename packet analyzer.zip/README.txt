A simple packet analyzer utility using pcap library.

Run ./build to create a binary inside bin folder.

Example:

$ ./analyzer -i wlan1    (may need sudo)
$ ./analyzer -f ../capture/capture.pcap
