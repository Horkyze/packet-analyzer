
typedef	struct ipv4_h
{
	u_char version_ihl[1];
	u_char dscp_enc[1];
	//u_short length;
	u_char length[2];
	u_char identification[2];
	u_char flags_fragment_offset[2];
	u_char ttl[1];
	u_char protocol[1];
	u_char header_chksm[2];
	u_char src_ip_addr[4];
	u_char dst_ip_addr[4];
	u_char options[4]; // if ihl > 5

}ipv4_h;

typedef struct Packet{
	int number;
	ipv4_h * header;
	u_char * data;
}Packet;

LL * packets_ll;



// create packets linked list 
void parse_packets(){
	packets_ll = LL_init();
	Hash_table * ht = init_hash_table(1000);



	Frame * f;
	Packet * p;
	Item * curr;
	curr = frames_ll->head;
	while(curr) {		
		f = curr->data; // frame struct
		if (  ( (eth_2_h*)(f->eth_header))->eth_type[1] == 0x06  )
		{
			printf("arp\n");
			continue;
		}
		p->header = f->data + 14;
		printf("SRC IP address: ");
		print_ip( (p->header)->src_ip_addr );
		printf("\t: %u bytes\n", (p->header)->length[1], (p->header)->length[2]);
		insert_h(ht, (p->header)->src_ip_addr, 4);
		
	    curr = curr->next; // next item in LL
	}
}